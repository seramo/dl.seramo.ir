s=tf('s')
for a=[1 5 10 15]
    g=(1.151*s+0.1774)/(s^3+0.739*s^2+0.921*s)
    m=(s+a)
    G=series(g,m)
    T=feedback(G,1)
    step(T)
    hold on
end
legend('s+1','s+5','s+10','s+15')
